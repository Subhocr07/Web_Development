let envName=(process.env.USERNAME);
console.log(`Hello ${envName}`)
console.log(process.env)