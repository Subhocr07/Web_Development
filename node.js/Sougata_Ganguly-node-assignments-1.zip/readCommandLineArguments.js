let name=process.argv
console.log('Hello ' + name[2])