const http=require('http');
const fs=require('fs');
const fileContent=fs.readFileSync('index.html')

const server=http.createServer((req,res)=>{

    res.writeHead(200,{'contet-type':'text/html'});
    res.end(fileContent);
});
server.listen(5000,()=>{
    console.log('Listening on port 5000')
})